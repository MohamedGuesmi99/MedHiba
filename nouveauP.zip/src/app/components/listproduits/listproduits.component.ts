import { Component, OnInit } from '@angular/core';
import { Produit } from 'src/app/classes/produit';
import { ProduitService } from 'src/app/services/produit.service';

@Component({
  selector: 'app-listproduits',
  templateUrl: './listproduits.component.html',
  styleUrls: ['./listproduits.component.css']
})
export class ListproduitsComponent implements OnInit {

  
  constructor(private produitService:ProduitService) { }
  lesprod!:Produit[];
  ngOnInit(): void {
    this.getProducts()
  }


  getProducts(){
      this.produitService.getProduits().subscribe ((data: any) =>{
        this.lesprod=data
      })
    
    }
  }



  

