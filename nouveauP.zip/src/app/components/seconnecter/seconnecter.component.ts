import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seconnecter',
  templateUrl: './seconnecter.component.html',
  styleUrls: ['./seconnecter.component.css']
})
export class SeconnecterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
