import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chariot',
  templateUrl: './chariot.component.html',
  styleUrls: ['./chariot.component.css']
})
export class ChariotComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
