import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-produit',
  templateUrl: './produit.component.html',
  styleUrls: ['./produit.component.css']
})
export class ProduitComponent implements OnInit {

  constructor() { }
  @Input() title!:string;
  @Input() cat!:string;
  @Input() image!:string;
  @Input() prix!:number;

  


  ngOnInit(): void {
  }

}
