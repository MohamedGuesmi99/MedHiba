export class Produit {
    constructor(public id:number, public title:string, public image:string, public prix:number,public categ:string)
    {}
}
