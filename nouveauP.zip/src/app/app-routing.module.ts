import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChariotComponent } from './components/chariot/chariot.component';
import { ListproduitsComponent } from './components/listproduits/listproduits.component';
import { SeconnecterComponent } from './components/seconnecter/seconnecter.component';

const routes: Routes = [
{path:'listproduits', title:'Produits',component:ListproduitsComponent},
{path:'chariot',title:'Chariot',component:ChariotComponent},
{path:'seconnecter', title:'Se Connecter',component:SeconnecterComponent},
{path:'', redirectTo:'listproduits', pathMatch:'full'}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
