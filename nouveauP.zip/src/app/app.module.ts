import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListproduitsComponent } from './components/listproduits/listproduits.component';
import { SeconnecterComponent } from './components/seconnecter/seconnecter.component';
import { ChariotComponent } from './components/chariot/chariot.component';
import { MenuComponent } from './components/menu/menu.component';
import { RouterModule } from '@angular/router';
import { ProduitComponent } from './components/produit/produit.component';

@NgModule({
  declarations: [
    AppComponent,
    ListproduitsComponent,
    SeconnecterComponent,
    ChariotComponent,
    MenuComponent,
    ProduitComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
